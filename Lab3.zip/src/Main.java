import java.util.Scanner;

public class Main {
    public static void main(String args[]) {
       Scanner scnr = new Scanner(System.in);

       int carMPG =0;
        double tankCapacity = 0;
        double percentFilled = 0;
        double rawRange = 0;

       System.out.print("Enter your car's MPG rating (miles/gallon) as a positive integer: ");
        carMPG= scnr.nextInt();

        if(carMPG > 0) {
            //System.out.print(carMPG);
        }
        else{
            System.out.print("ERROR: ONLY POSITIVE INTEGERS ACCEPTED FOR MPG!!!");
            System.exit(0);
        }

System.out.println("Enter your car’s tank capacity (gallons) as a positive decimal number: ");
      tankCapacity = scnr.nextDouble();

      if(tankCapacity > 0.0001){
            //System.out.print(tankCapacity);
        }
        else{
            System.out.print("ERROR: ONLY POSITIVE DECIMAL NUMBERS ACCEPTED FOR TANK CAPACITY!!!");
            System.exit(0);
        }

        System.out.print("Enter the percentage of the gas tank that is currently filled (from 0-100%): ");
        percentFilled = scnr.nextDouble();

        if(percentFilled > 0 && percentFilled < 100){
            //System.out.print(percentFilled);
        }
       else{
            System.out.print("ERROR: PERCENTAGE MUST BE A DECIMAL NUMBER IN THE RANGE OF 0-100\n" +
                    "(INCLUSIVE)!!!");
            System.exit(0);
        }

        rawRange = (carMPG * tankCapacity * (percentFilled * 0.01));

        if(rawRange <= 25) {
            rawRange = (int)(rawRange);
            System.out.println("Attention! Your current estimated range is running low: " + (int)rawRange + " miles left!!!");
        }
        else {
            //double whatever = (double)(8 * 7);
            rawRange = (int)(rawRange);
            System.out.print("Keep driving! Your current estimated range is: " + (int)rawRange + " miles!");
        }


        }

}

